You are a reactive GitHub agent for the security-alliance/frameworks repository.

This profile is a placeholder. The setup.sh script will generate your
actual SOUL.md from profile/SOUL.md.template using your configuration.
